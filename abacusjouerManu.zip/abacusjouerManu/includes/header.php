<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Page À toi de jouer du site Calcul mental</title>

    <!-- Ajout de cdn qui seront spécifiques à notre thème -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <!-- Ajout d'une nouvelle feuille de style qui sera spécifique à notre thème -->
    <link rel="stylesheet" href="../css/style.css">
    <!-- <link href="<?php //bloginfo('template_directory');?>/blog.css" rel="stylesheet">
    <base href="/site_cv/wordpress/wp-content/themes/spacious/" target="_blank"> -->

    <!--[endif]-->
    <?php //wp_head(); ?>

  </head>
